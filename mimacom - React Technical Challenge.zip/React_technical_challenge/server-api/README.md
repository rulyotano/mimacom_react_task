# Shopping list fake api

## Install dependencies

```
$ yarn
```

## Run the Rest API

```
$ yarn start
```

This will run the test API in `localhost:3000`

> The test API uses [json-server](https://github.com/typicode/json-server) please refer to the documentation to see the API usage
